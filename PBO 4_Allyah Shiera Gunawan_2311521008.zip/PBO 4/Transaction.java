public abstract class Transaction {
    

    String namaPelanggan;
    String nomorFaktur;
    String kodeBarang;
    String namaBarang;
    Long hargaBarang;
    Long jumlahBarang;
    Long totalBayar;

}

